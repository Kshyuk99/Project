package edu.du.teamportpoilo_pyl;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TeamPortpoiloPylApplication {

    public static void main(String[] args) {
        SpringApplication.run(TeamPortpoiloPylApplication.class, args);
    }

}
